"""A small Flask microservice: REST API that enqueues tasks for the worker service."""
import os
import time
import uuid
from flask import Flask, request, jsonify

app = Flask(__name__)

START_TIME = time.time()
REQUEST_COUNT = 0
TASKS = {}  # in-memory demo store; swap for Redis/SQS/RabbitMQ in production


@app.before_request
def count_requests():
    global REQUEST_COUNT
    REQUEST_COUNT += 1


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "uptime_seconds": round(time.time() - START_TIME, 1)})


@app.route("/metrics", methods=["GET"])
def metrics():
    return jsonify({
        "request_count": REQUEST_COUNT,
        "tasks_in_memory": len(TASKS),
        "uptime_seconds": round(time.time() - START_TIME, 1),
    })


@app.route("/tasks", methods=["POST"])
def create_task():
    body = request.get_json(silent=True) or {}
    task_id = str(uuid.uuid4())
    TASKS[task_id] = {"id": task_id, "payload": body.get("payload"), "status": "queued"}
    return jsonify(TASKS[task_id]), 201


@app.route("/tasks/<task_id>", methods=["GET"])
def get_task(task_id):
    task = TASKS.get(task_id)
    if not task:
        return jsonify({"error": "not found"}), 404
    return jsonify(task)


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    app.run(host="0.0.0.0", port=port)
