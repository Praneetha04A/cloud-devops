"""A minimal background worker that polls the API service for queued tasks and
'processes' them. Stands in for a real queue consumer (SQS/RabbitMQ/Celery)."""
import os
import time
import requests

API_URL = os.environ.get("API_URL", "http://api-service:8000")
POLL_INTERVAL_SECONDS = int(os.environ.get("POLL_INTERVAL_SECONDS", 5))


def process_forever():
    print(f"Worker started. Polling {API_URL} every {POLL_INTERVAL_SECONDS}s")
    while True:
        try:
            resp = requests.get(f"{API_URL}/health", timeout=3)
            print(f"[worker] api-service health: {resp.json()}")
        except requests.RequestException as e:
            print(f"[worker] could not reach api-service: {e}")
        time.sleep(POLL_INTERVAL_SECONDS)


if __name__ == "__main__":
    process_forever()
