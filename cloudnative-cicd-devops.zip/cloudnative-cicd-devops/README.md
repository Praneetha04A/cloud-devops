# Cloud-Native Distributed Application Deployment and Automated CI/CD Infrastructure

A cloud-native microservices reference architecture: two containerized services
orchestrated with Docker Compose (locally) / Kubernetes (in the cloud), a GitHub
Actions CI/CD pipeline (build → test → containerize → push → deploy), infrastructure
provisioning via Terraform, and basic application monitoring.

Run it:
```bash
docker compose up --build
curl http://localhost:8000/health
```

## Architecture

```
┌─────────────┐      ┌────────────────┐      ┌───────────────┐
│  api-service │──────▶  worker-service │──────▶   (queue /    │
│  (Flask API) │      │  (background    │      │   in-memory   │
│              │◀─────│   task worker)  │◀─────│   for demo)   │
└─────────────┘      └────────────────┘      └───────────────┘
       │                       │
       └────────── /health, /metrics ─────────┘
                       │
              Docker Compose (local) /
              Kubernetes Deployment + Service (cloud)
                       │
        GitHub Actions: lint → test → build image →
        push to registry → deploy (kubectl apply)
```

## Project structure

```
cloudnative-cicd-devops/
├── app/
│   ├── api_service/          # Flask REST API microservice
│   │   ├── main.py
│   │   ├── Dockerfile
│   │   └── requirements.txt
│   └── worker_service/       # background worker microservice
│       ├── worker.py
│       ├── Dockerfile
│       └── requirements.txt
├── tests/
│   └── test_api.py
├── k8s/
│   ├── api-deployment.yaml
│   ├── api-service.yaml
│   └── worker-deployment.yaml
├── terraform/
│   └── main.tf               # example cloud resource provisioning (AWS ECR + ECS)
├── .github/workflows/
│   └── ci-cd.yml             # build, test, containerize, push, deploy
├── Jenkinsfile                # alternative CI/CD pipeline definition (Jenkins)
├── docker-compose.yml         # local multi-container orchestration
└── README.md
```

## Quickstart (local)

```bash
# Run both services + local orchestration
docker compose up --build

# API is now live at http://localhost:8000
curl http://localhost:8000/health
curl -X POST http://localhost:8000/tasks -H "Content-Type: application/json" \
     -d '{"payload": "example"}'
```

## Running tests

```bash
pip install -r app/api_service/requirements.txt
pytest tests/
```

## CI/CD pipeline

`.github/workflows/ci-cd.yml` runs on every push:
1. **Lint & test** each service
2. **Build** Docker images for `api-service` and `worker-service`
3. **Push** images to a container registry (GHCR by default)
4. **Deploy** by applying the manifests in `k8s/` to a cluster (`kubectl apply`)

A `Jenkinsfile` is included as an alternative pipeline definition for teams running
Jenkins instead of GitHub Actions — same build/test/containerize/deploy stages.

## Infrastructure as code

`terraform/main.tf` provisions the cloud side: an ECR repository for images and an
ECS Fargate service to run the containers, as an example of automated, reproducible
cloud resource provisioning. Adjust the provider block for GCP/Azure as needed.

## Monitoring

Each service exposes `/health` (liveness) and `/metrics` (basic counters) endpoints
that a monitoring stack (Prometheus/CloudWatch) can scrape.

## License

MIT
