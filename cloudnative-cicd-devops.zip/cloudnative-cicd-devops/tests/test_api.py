import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "app" / "api_service"))
from main import app  # noqa: E402


def client():
    app.testing = True
    return app.test_client()


def test_health():
    resp = client().get("/health")
    assert resp.status_code == 200
    assert resp.get_json()["status"] == "ok"


def test_create_and_get_task():
    c = client()
    resp = c.post("/tasks", json={"payload": "example"})
    assert resp.status_code == 201
    task = resp.get_json()
    assert task["status"] == "queued"

    resp2 = c.get(f"/tasks/{task['id']}")
    assert resp2.status_code == 200
    assert resp2.get_json()["id"] == task["id"]


def test_get_missing_task():
    resp = client().get("/tasks/does-not-exist")
    assert resp.status_code == 404


def test_metrics():
    resp = client().get("/metrics")
    assert resp.status_code == 200
    assert "request_count" in resp.get_json()
